public class Main {
    public static void main(String[] args) {
        Divisao a = new Divisao();
        a.dividir();



    }
}