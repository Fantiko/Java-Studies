public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        Login l = new Login("kaio", "1234");

        l.fazerLogin("Kaio","4321");
        System.out.println("-------------------------------------------");
        l.fazerLogin("kaio", "1234");









    }
}