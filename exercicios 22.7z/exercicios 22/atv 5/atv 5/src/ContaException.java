public class ContaException extends Exception{
    public ContaException ( String _mensagem) {
        // Deve chamar o construtor da superclasse.
        super(_mensagem);
    }
}
